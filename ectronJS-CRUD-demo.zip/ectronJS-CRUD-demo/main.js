const { app, BrowserWindow, Menu } = require('electron')

function createWindow () {
  // Create the browser window.
  const win = new BrowserWindow({
    width: 500,
    height: 600,
    webPreferences: {
      nodeIntegration: true
    }
  })

  // and load the index.html of the app.
  win.loadFile('index.html')

  var menu  = Menu.buildFromTemplate([
    {
        label: 'Menu',
        submenu: [
            {label: 'Adding new file'},
            { 
                label: 'Exit',
                click(){
                    app.quit();
                }
            }
        ]
    }
    ])
    
    Menu.setApplicationMenu(menu);

  // Open the DevTools.
  win.webContents.openDevTools()
}
app.whenReady().then(createWindow)
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow()
  }
})